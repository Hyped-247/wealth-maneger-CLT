from setuptools import setup

setup(
    name='Real Estate Investment Calculator',
    version='0.0.1',
    description='a pip-installable package example',
    license='MIT',
    packages=['/Users/mohammad/PycharmProjects/wealth-maneger-CLT'],
    author='Mohammad Mahjoub',
    author_email='youvsyou47@gmail.com',
    keywords=['example'],
    url='https://github.com/Hyped-247/wealth-maneger-CLT.git'
)
